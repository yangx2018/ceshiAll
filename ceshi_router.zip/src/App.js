
import React,{Suspense} from 'react';
import logo from './logo.svg';
import './App.scss';
import { Route, Switch, BrowserRouter,Redirect  } from "react-router-dom";
import Ceshi from './ceshi'
import Ceshi1Dva from './ceshi_dva/father'
import CeshiReduc from './ceshi_redux/index'
import Timer from './timer'
import ComponentTest from './component'
import Draw from './ceshi_draw'
import CP from './ceshi_draw/chepai';
import Pullrefresh from './ceshi_pull';
import CompressImg from './ceshi_compressImg'
// const OtherCeshi2 = React.lazy(() => import('./ceshi/ceshi2'));
const App = () => {
  // function MyComponent() {
  //   return (
  //     <div>
  //       <Suspense fallback={<div>Loading..............................................................</div>}>
  //         <OtherCeshi2 />
  //       </Suspense>
  //     </div>
  //   );
  // }

  return (
    <BrowserRouter>
      <Suspense fallback={<div>LoadingLoadingLoadingLoadingLoadingLoadingLoadingLoading</div>}>
        <Switch>
          
          {/* <Redirect from="/ceshi4" to="/ceshi3" /> */}
          <Route path="/ceshi"   component={Ceshi} />
          <Route path="/timer" component={Timer} /> 
          <Route path="/component"  component={ComponentTest} />
          <Route path="/ceshiDva"  component={Ceshi1Dva} />
          <Route path="/draw"  component={Draw} />
          <Route path="/compressimg"  component={CompressImg} />
          {/* <Route path="/ceshi6" component={Ceshi3} >
            <Route path="/ceshi62" component={Ceshi2} /> 
          </Route> */}
          <Route path="/"  component={CP} />
        </Switch>
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
