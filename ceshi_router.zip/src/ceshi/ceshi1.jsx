
import { Route, Switch,Link, BrowserRouter,Redirect  } from "react-router-dom";
import Ceshi2222 from './ceshi2'
import { useState } from "react";
const Ceshi1 = () => {
  // <BrowserRouter basename="ceshi1">
    //   <Switch>
    //     <Link to="/today"/>
    //     <Link to="/y"/>
    //     <Link to="/tomorrow"/>
    //   </Switch>
    // </BrowserRouter>
  const  [asaa,setasaa] = useState(1)
  const llll = () => {
      setasaa(2)
  }
  window.dddd = function(){
    console.log("ddd")
  }
  console.log(asaa,"ceshi11111",window.dddd())
  return (
    
    <div>
      <BrowserRouter basename="ceshi1">
          <Link to="/today">{asaa}</Link>
          <Link to="/y">bbb</Link>
          <Link to="/tomorrow">ccc</Link>
          
      </BrowserRouter>
      <button onClick={llll}>aaaaaaaaaaa</button>
      <Ceshi2222></Ceshi2222>
    </div>
  );
}

export default Ceshi1;

