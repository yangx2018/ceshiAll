
import React, { memo } from 'react'
import { Link  } from "react-router-dom";
const Ceshi2 = memo((props) => {
  //memo可以防止父组件更新，不涉及子组件可组织子组件更新
  console.log("222222222")
  
  return (
    <div className="App">
       <Link to={location => ({ ...location, pathname: "/ceshi3",state:{id:"111"} })}>{11}</Link>
    </div>
  );
})

export default Ceshi2;

