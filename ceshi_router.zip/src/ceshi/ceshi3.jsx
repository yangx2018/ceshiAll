
import { Link  } from "react-router-dom";
const Ceshi3 = (props) => {
  console.log(props)
  window.dddd = function(){
    console.log("ddddddddddddddddddddddd")
  }
  console.log("ceshi3",window.dddd())
  return (
    <div className="App">
       <Link to="/ceshi2">ceshi3</Link>
    </div>
  );
}

export default Ceshi3;

