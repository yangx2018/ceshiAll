
import React,{Suspense} from 'react';
import { Route, Switch, BrowserRouter,Redirect,useRouteMatch  } from "react-router-dom";
import Ceshi1 from './ceshi1'
import Ceshi2 from './ceshi2'
import Ceshi3 from './ceshi3'

const OtherCeshi2 = React.lazy(() => import('./ceshi2'));
const Ceshi = () => {

  const { path, url }  = useRouteMatch();
  console.log(path,url)

  function MyComponent() {
    return (
      <div>
        <Suspense fallback={<div>Loading..............................................................</div>}>
          <OtherCeshi2 />
        </Suspense>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Suspense fallback={<div>LoadingLoadingLoadingLoadingLoadingLoadingLoadingLoading</div>}>
        <Switch>
          {/* <Redirect from="/ceshi4" to="/ceshi3" /> */}
          
          <Route path={`${path}/ceshi3`} exact component={Ceshi3} /> 
          {/* <Route path="/ceshi2" exact strict  component={Ceshi2} /> */}
          <Route path={`${path}/ceshi2`}  component={Ceshi2} />
          <Route path={`${path}/ceshi5`} render={() => <div>ceshi5</div>} />
          <Route path={`${path}/aaa`} component={MyComponent} />
          <Route path="/" component={Ceshi1} />
        </Switch>
      </Suspense>
    </BrowserRouter>
  );
}

export default Ceshi;
