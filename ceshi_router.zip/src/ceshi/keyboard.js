import React,{useState} from 'react';
import {  } from 'antd-mobile';

import './KeyboardStyle.less'

const Keyboard = (props: {}) => {

    const [showKeyboard,setShowKeyboard] = useState<boolean>(false);
    const [showCarNum,setShowCarNum] = useState<string>('');
    const [selectIndex,setSelectIndex] = useState<number>(0);
    const [carNum,setCarNum] = useState<(number | string)[]>([]);
    const [err,setErr] = useState<boolean>(false);
    
    const keys :string[] = [
        "京","津","沪","渝","冀","晋","蒙","辽","吉","黑","苏","浙","皖","闽","赣","鲁","豫","鄂",
        "湘","奥","桂","琼","川","贵","云","藏","陕","甘","青","宁","新"
    ]
    const keys2 :(number | string)[] = [
        1,2,3,4,5,6,7,8,9,0,"Q","W","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J",
        "K","L","Z","X","C","V","B","N","M"
    ]

    function showKeyBoardF(){
        setShowKeyboard(true)
    };

    const itemClick = (index:number) => {
        setSelectIndex(index)
    };

    const provinceClick = (item:any) => {
        // debugger;
        carNum[selectIndex] = item;
        setCarNum(carNum)
        setSelectIndex(selectIndex + 1)
    };

    function getCarNum(){
        console.log("???getCarNum")
        // const { carNum } = this.state;
        // const { onChange } = this.props;
        // if (onChange) {
        //   let num = carNum.join("");
        //   if (num.length < 7) {
        //     this.setState({
        //       err: true
        //     });
        //     return;
        //   }
        //   onChange(carNum.join(""));
        //   this.setState({
        //     showKeyboard: false,
        //     showCarNum: carNum.join(""),
        //     err: false
        //   });
        // }
    };

    return (
        <>
        <div className="cntxt" onClick={showKeyBoardF}>
          {showCarNum}
          {!showCarNum && <span style={{ color: "#999" }}>点击输入车牌</span>}
        </div>
        {showKeyboard && (
          <div className="cnBg">
            <div className="cnmodelflex">
              <div className="cnmodel">
                <div className="cnmodelTitle">
                  <div>请输入车牌号</div>
                  <div
                    className="cnmodelClose"
                    onClick={() => {
                      setShowKeyboard(false)
                    }}
                  ></div>
                </div>
                <div className="cnNumK">
                  <div
                    onClick={() => {
                      itemClick(0);
                    }}
                    className={
                      selectIndex == 0 ? "cnNumItems" : "cnNumItem"
                    }
                  >
                    {carNum && carNum[0] && carNum[0]}
                  </div>
                  <div
                    onClick={() => {
                      itemClick(1);
                    }}
                    className={
                      selectIndex == 1 ? "cnNumItems" : "cnNumItem"
                    }
                  >
                    {carNum && carNum[1] && carNum[1]}
                  </div>
                  <div>•</div>
                  <div
                    onClick={() => {
                      itemClick(2);
                    }}
                    className={
                      selectIndex == 2 ? "cnNumItems" : "cnNumItem"
                    }
                  >
                    {carNum && carNum[2] && carNum[2]}
                  </div>
                  <div
                    onClick={() => {
                      itemClick(3);
                    }}
                    className={
                      selectIndex == 3 ? "cnNumItems" : "cnNumItem"
                    }
                  >
                    {carNum && carNum[3] && carNum[3]}
                  </div>
                  <div
                    onClick={() => {
                      itemClick(4);
                    }}
                    className={
                      selectIndex == 4 ? "cnNumItems" : "cnNumItem"
                    }
                  >
                    {carNum && carNum[4] && carNum[4]}
                  </div>
                  <div
                    onClick={() => {
                      itemClick(5);
                    }}
                    className={
                      selectIndex == 5 ? "cnNumItems" : "cnNumItem"
                    }
                  >
                    {carNum && carNum[5] && carNum[5]}
                  </div>
                  <div
                    onClick={() => {
                      itemClick(6);
                    }}
                    className={
                      selectIndex == 6 ? "cnNumItems" : "cnNumItem"
                    }
                  >
                    {carNum && carNum[6] && carNum[6]}
                  </div>
                  <div
                    onClick={() => {
                      itemClick(7);
                    }}
                    className={
                      selectIndex == 7 ? "cnNumItems" : "cnNumItem"
                    }
                  >
                    {carNum && carNum[7] && carNum[7]}
                    {!carNum[7] && <img width="100%" src=""></img>}
                  </div>
                </div>
                {err && <div className="carerr">请输入正确车牌号</div>}
                <div
                  style={{ display: "flex", justifyContent: "space-between" }}
                >
                  <div className="cnBtn" onClick={getCarNum}>
                    确定
                  </div>
                  <div
                    className="cnBtn1"
                    onClick={() => {
                      setCarNum([])
                      setSelectIndex(0)
                    }}
                  >
                    重输
                  </div>
                </div>
              </div>
            </div>

            <div className="keyboard">
              {selectIndex === 0 &&
                keys.map((item) => (
                  <div
                    className="keyItem"
                    onClick={() => {
                      provinceClick(item);
                    }}
                  >
                    {item}
                  </div>
                ))}
              {selectIndex !== 0 &&
                keys2.map((item,index) => (
                  <div
                    className="keyItem2"
                    key={index}
                    onClick={() => {
                      provinceClick(item);
                    }}
                  >
                    {item}
                  </div>
                ))}
            </div>
          </div>
        )}
      </>
    );
}
export default Keyboard
