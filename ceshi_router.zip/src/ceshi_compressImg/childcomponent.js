import React from 'react';
import {ImagePicker} from 'antd-mobile';
import '../../node_modules/antd-mobile/dist/antd-mobile.css'

const BznImagesPicker = (props) => {

  const maxSize = 3027;

  const handleChange = (files, operationType, index) => {
    if (operationType === 'add') {
   
      const file = [...files].pop().file;
      console.log(files)
      if (file.size > 3 * 1024 * 1024) {
        let filearr = files.slice(0,files.length-1)
        let rate = 0.6;
        let reader = new FileReader();
        reader.readAsDataURL(file);
        let img = new Image();
        reader.onload = function (e) {
          img.src = e.target.result;
        };
        img.onload = function () {
          let canvas = document.createElement('canvas');
          let context = canvas.getContext('2d');
          // 文件大小KB
          const fileSizeKB = Math.floor(file.size / 1024);
          // console.log('file size：', fileSizeKB, 'kb');
          // 配置rate和maxSize的关系
          if (fileSizeKB * rate > maxSize) {
            rate = Math.floor(maxSize / fileSizeKB * 10) / 10;
            // console.log('file rate：', rate);
            // console.log('file size*rate：', fileSizeKB * rate, 'kb');
          }
          // 缩放比例，默认0.5
          let targetW = canvas.width = this.width * rate;
          let targetH = canvas.height = this.height * rate;
          context.clearRect(0, 0, targetW, targetH);
          context.drawImage(img, 0, 0, targetW, targetH);
          let base64 = canvas.toDataURL(file.type, 1)
          canvas.toBlob(function (blob) {
                const newImage = new File([blob], file.name, {type: file.type});
                // console.log(newImage,newImage.size / 1024, 'kb');
                // props.onChange && props.onChange([{file: newImage}], operationType, index);
                props.onChange && props.onChange([...filearr,{file: newImage,url:base64}], operationType, index);
          });
        };
      } else {
        props.onChange && props.onChange(files, operationType, index);
      }
    } else {
      props.onChange && props.onChange(files, operationType, index);
    }
  };

  const handleImageClick = (index, files) => {
    props.onImageClick && props.onImageClick(index, files);
  };

  return (
        <ImagePicker
          files={props.files}
          onChange={handleChange}
          onImageClick={handleImageClick}
          selectable={props.files.length < props.filesLength}
          multiple={props.multiple}
        />
  );
};

export default BznImagesPicker;