import React,{useState} from 'react';
import {Button, ImagePicker, Toast} from 'antd-mobile';
import BznImagesPicker from './childcomponent';
import '../../node_modules/antd-mobile/dist/antd-mobile.css';
import ImageCompressor from 'image-compressor.js';

const CompressImg = () => {


    const [filesarr,setFilesarr] = useState([]);
    const [filesarr1,setFilesarr1] = useState([])

    function base64toBlob(base64Data, contentType) {
        contentType = contentType || '';
        var sliceSize = 1024;
        console.log("base64Data", base64Data)
        var byteCharacters = atob(base64Data.substring(base64Data.indexOf(",") + 1));
        var bytesLength = byteCharacters.length;
        var slicesCount = Math.ceil(bytesLength / sliceSize);
        var byteArrays = new Array(slicesCount);
        for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
          var begin = sliceIndex * sliceSize;
          var end = Math.min(begin + sliceSize, bytesLength);
          var bytes = new Array(end - begin);
          for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
            bytes[i] = byteCharacters[offset].charCodeAt(0);
          }
          byteArrays[sliceIndex] = new Uint8Array(bytes);
        }
        return new Blob(byteArrays, {type: contentType});
    }

    const compressImg = (file,options,callback) => {
        var imgname = file.name;
        var imgtype = (imgname.substring(imgname.lastIndexOf('.') + 1)).toLowerCase();
        if(imgtype == 'jpg' || imgtype == 'jpeg'){
            imgtype = 'image/jpeg';
        }else{
            imgtype = 'image/png';
        }
        // 用FileReader读取文件
        var reader = new FileReader();
        // 将图片读取为base64
        reader.readAsDataURL(file);
        reader.onload = function(evt){
            var base64 = evt.target.result;
            // 创建图片对象
            var img = new Image();
            // 用图片对象加载读入的base64
            img.src = base64;
            img.onload = function () {
                var that = this,
                canvas = document.createElement('canvas'),
                ctx = canvas.getContext('2d');
                canvas.setAttribute('width', that.width * 0.6);
                canvas.setAttribute('height', that.height* 0.6);
                // 将图片画入canvas
                ctx.drawImage(that, 0, 0, that.width, that.height);
                console.log(base64)
                base64 = canvas.toDataURL(imgtype, 1)
                callback(base64);
                // 压缩到指定体积以下（M）
                // if(options.size){
                //     var scale = 0.6;
                //     (function f(scale){
                //         if(base64.length / 1024 / 1024 > options.size && scale > 0){
                //             console.log("!!!1",base64.length / 1024 / 1024,options.size)
                //             base64 = canvas.toDataURL(imgtype, scale);
                //             scale = scale - 0.1;
                //             f(scale);
                //         }else{
                //             callback(base64);
                            
                //         }
                //     })(scale); 
                //     console.log(options.size,base64)
                // } else if(options.scale){
                //     // 按比率压缩
                //     base64 = canvas.toDataURL(imgtype, options.scale);
                //     callback(base64);
                // }
                
            }
        }
    };

    const upload = () => {
        console.log(filesarr,filesarr1)
        // console.log(compressImg(filesarr[0].file,{},(e) => console.log("????",e)))
        console.log(base64toBlob(filesarr[0].url))
        for(let i=0;i<filesarr.length;i++){
            new ImageCompressor(filesarr[i].file, {
                quality: .6,
                maxHeight:250,
                minWidth:250,
                success(result) {
                //   const formData = new FormData(); // FormData学习地址 https://developer.mozilla.org/zh-CN/docs/Web/API/FormData
                //   formData.append('file', result, result.name);
                    console.log(result)
                },
                error(e) {
                  console.log(e.message);
                },
            });
        }
    }

    return (
        <>
            <div>
                <Button onClick={upload}>上传</Button>
            </div>
            <div>
                <ImagePicker
                    files={filesarr}
                    onChange={(files, type, index) => {
                        setFilesarr(files)}}
                    selectable={filesarr.length < 5}
                    onImageClick={(index, fs) => console.log(index, fs)}
                    // accept="image/gif,image/jpeg,image/jpg,image/png"
                />
                <img src={filesarr.length>0?filesarr[0].url:''} alt="" width="100" />

                <BznImagesPicker
                    files={filesarr1}
                    onImageClick={() => console.log("111")} 
                    onChange={(files, type, index) => {
                        setFilesarr1(files)}}
                    filesLength={5}
                    multiple={false}
                />
                <img src={filesarr1.length>0?filesarr1[0].url:''} alt="" width="100"  />
            </div>
        </>
    );
}

export default CompressImg;

