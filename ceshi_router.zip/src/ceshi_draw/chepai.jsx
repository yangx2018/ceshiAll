import { useState,useRef } from "react";
import {Button} from "antd-mobile";
import '../../node_modules/antd-mobile/dist/antd-mobile.css'
import LicenseKeyboard from 'vehicle-plate-keyboard';
import 'vehicle-plate-keyboard/dist/main.css';

const CeshiCp = () => {

    const [showKeyboard, setShowKeyboard] = useState(false);
    const [value, setValue] = useState("");

    return (
        <>
            <div>
            <LicenseKeyboard
                visible={showKeyboard}
                done={() => setShowKeyboard(false)}
                onChange={(value) => setValue(value)}
                value={value}
            />
                <button onClick={() => setShowKeyboard(!showKeyboard)}>{"键盘⌨️"}</button>
                <p>{value}</p>
                <p>车牌</p>
            </div>
        </>
    );
}

export default CeshiCp;

