import { useState,useRef } from "react";
import {Modal,Flex,Button} from "antd-mobile";
import '../../node_modules/antd-mobile/dist/antd-mobile.css'
import CanvasDraw from 'react-canvas-draw';

const CeshiDraw = () => {
  
    const canvasRef = useRef();//访问申请签名
    const [drawModal,setDrawModal] = useState(false)//判断是否要打开申请须知的模态框
    const [show,setShow] = useState(false)

    return (
        <>
            <div>
                <Button type="primary" size="small" inline style={{marginLeft: '4px'}} onClick={() => setDrawModal(true)}>提交</Button>
                <p>这里显示画布的测试</p>
            </div>
            <Modal
                visible={drawModal}
                maskClosable={false}
                title='申请须知'
                animationType="slide-up"
                // transparent
                style={{width:'90%',height:'80%'}}
                // footer={[{ text: '确认', onPress: () => { console.log('ok');} },{ text: '重置签名', onPress: () => { console.log('tt'); } }]}
            >
                <Flex justify="center" direction="column" className="notice" >
                <Flex.Item className="title" style={{fontWeight:'600',textIndent:'25px'}}>欢迎您来访中船黄埔文冲船舶有限公司，请您进入公司前认真阅读以下须知：</Flex.Item>
                <Flex.Item className="line">一、进入公司，请注意遵守各类安全警示标志要求，进入生产场地参观，必须有专人带领，规范装束和正确穿戴防护用品。</Flex.Item>
                <Flex.Item className="line">二、在生产场地请走安全通道，注意安全标志提醒，禁止私自进入无关区域，未经许可，禁止动用各类设备。</Flex.Item>
                <Flex.Item className="line">三、公司区域内禁止吸游烟，若有需要可到指定地点吸烟。</Flex.Item>
                <Flex.Item className="line">四、遵守公司6S管理要求，产生的垃圾请清理干净并分类投放到垃圾斗内。</Flex.Item>
                <Flex.Item className="line">五、进入厂区按接待人员指引在规定车位停放，严禁停放在生产区域和堵塞消防通道。</Flex.Item>
                <Flex.Item className="line">六、未经允许，不得擅自对我司在建产品、码头、厂房、车间等拍摄录像，或者以其作为背景进行拍摄录像留存及上传至互联网。</Flex.Item>
                <Flex.Item className="line">七、不得通过微信、QQ、抖音、快手、陌陌等网络社交平台谈论、传播我司军品生产建造相关信息。</Flex.Item>
                <Flex.Item className="line">八、严格按照我司指定接待路线、参观区域、工作区域活动，未经允许，不得进入无关场所。</Flex.Item>
                <Flex.Item className="line">九、进入军品舰船、保密要害部门部位、涉密会场不准携带手机等具有录音录像功能电子设备。</Flex.Item>
                <Flex.Item className="line">十、发现涉嫌危害国家安全的可疑人员或者收到相关可疑信息，请及时向我司报告。举报有奖（电话82096465）</Flex.Item>
                <Flex.Item className="line">十一、不准盗窃、挪用，破坏我司生产物资及各类材料设备。</Flex.Item>
                <Flex.Item className="line">十二、不准在我司区域打架斗殴，寻衅滋事，酗酒闹事或其他侮辱他人等违法违纪行为。</Flex.Item>
                <Flex.Item className="line">十三、不得在黄埔文冲公司码头水域游泳、垂钓。</Flex.Item>
                <Flex.Item className="line">十四、公司上、下班前后10分钟，驾车人员不得在公司主干道行驶，驾车通过门岗、仓库门口及行人稠密路段、掉头、转弯，时速不得超过5km/h。</Flex.Item>
                <Flex.Item className="line" style={{width:'100%'}}>十五、应急电话</Flex.Item>
                <Flex.Item className="line">长洲厂区：保卫:82096452\消防：82502119；</Flex.Item>
                <Flex.Item className="line">文冲厂区：保卫82389933转110\消防82389933转999;</Flex.Item>
                <Flex.Item className="line">海工厂区：保卫：36660045\消防：36660119。</Flex.Item>
                <Flex.Item className="line">本人已了解中船黄埔文冲船舶有限公司进厂相关告知内容并已同步告知随行人员，承诺自觉遵守贵公司相关管理要求，如因未遵守告知内容造成相关事故（件），本人承担一切责任。</Flex.Item>
                <Flex.Item style={{marginTop:15,marginBottom:30}}>
                    <Button type="primary" size="middle" onClick={() => setShow(true)}>申请人签字</Button>
                </Flex.Item>
                {show?
                    <div className='canvas-area' style={{width:'100%',height:'100%',position:'fixed',left:0,top:0,border:'solid 1px #e0e0e0'}}>
                        <CanvasDraw
                            className='sign-canvas'
                            ref={canvasRef}
                            brushColor='#000'
                            gridColor='transparent'
                            brushRadius={3}
                            lazyRadius={0}
                            canvasWidth={'100%'}
                            canvasHeight={'100%'}
                            hideInterface
                        />
                        <Flex.Item  style={{position:'absolute',left:0,bottom:0,zIndex:1000}}>
                            <Button type="primary" size="small" inline  onClick={() => {canvasRef.current.clear()}}>重置签名</Button>
                            <Button type="primary" size="small" inline style={{marginLeft: '4px'}} onClick={() => {setShow(false)}}>提交</Button>
                        </Flex.Item>
                    </div>
                :<></>
                }
                {/* <Flex.Item style={{marginTop:15,marginBottom:30}}>
                    <Button type="primary" size="small" inline   onClick={() => {canvasRef.current.clear()}}>重置签名</Button>
                    <Button type="primary" size="small" inline style={{marginLeft: '4px'}}>提交</Button>
                </Flex.Item> */}
                </Flex>
            </Modal>
        </>
    );
}

export default CeshiDraw;

