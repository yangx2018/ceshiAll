import { useState } from "react";
import Ceshi2Dva from './son'
const Ceshi1Dva = () => {
  const [asaa,setasaa] = useState(1)
  const [as,setAs] = useState("ll")
  console.log(asaa,"ceshi11111")
  console.log(process.env.NODE_ENV,process.env.NODE_ENV === 'production')
  console.log(window.CONFIG.API_BASE_URL)
  console.log("GYS_BASE_URL",process.env.REACT_APP_GYS_BASE_URL,process.env.REACT_APP_PORTAL_URL)
  return (
    <div>
      <Ceshi2Dva kkk={asaa} bbb={() => setasaa(2)} />
      <Ceshi2Dva kkk={as} bbb={() => setAs("bbb")} />
      <p>这里显示 Son 组件的内容</p>
    </div>
  );
}

export default Ceshi1Dva;

