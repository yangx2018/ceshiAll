
import {  } from "react-router-dom";
import { useState } from "react";
const Ceshi2Dva = ({kkk,bbb}) => {
 
  console.log(kkk,"ceshi11111")
  return (
    <div onClick={bbb}>
      <p>这是Son,`````{kkk}</p>
    </div>
  );
}

export default Ceshi2Dva;

