import { useState,useRef,useCallback } from "react";
import { PullToRefresh, ListView, Button } from 'antd-mobile';
import { useRequest } from 'ahooks';
import '../../node_modules/antd-mobile/dist/antd-mobile.css'
import ScorllListView from './pull'
import { useEffect } from "react";



const Pullrefresh = () => {

    const bsRef = useRef();
  
    // const { data:projectData, loadMore, loading, loadingMore, reload, noMore } = useRequest((d) => ({
    //     url: 'https://ctmsbc.cssccloud.net/testApi/check/visitapplyrecord/queryAllVisitApplyRecordByParam?userToken=MjM0MDg=',
    //     method: 'POST',
    //     data: JSON.stringify({
    //         searchValue: "",
    //         startTime: "", 
    //         endTime: "", 
    //         orgCode: "base_chzy",
    //         pageNum: 1, 
    //         pageSize: 10,
    //         areaName: "", 
    //         cqThirdId: "", 
    //         bmThirdId: "" 
    //     })
    // }), {
    //     manual: false,
    //     loadMore: true,
    //     refreshDeps: [{
    //         searchValue: "",
    //         startTime: "", 
    //         endTime: "", 
    //         orgCode: "base_chzy",
    //         pageNum: 1, 
    //         pageSize: 10,
    //         areaName: "", 
    //         cqThirdId: "", 
    //         bmThirdId: "" 
    //     }],
    //     isNoMore: (d) => (d ? d.list.length >= d.total : false),
    //     formatResult: (resp) => {
    //         console.log(resp)
    //         return {
    //             list: resp?.list || [],
    //             total: resp?.total,
    //             pageNum: resp?.pageNum
    //         }
    //     }
    // })
    // console.log("???????????",projectData,loadMore, loading, loadingMore, reload, noMore)
    // useEffect(() => {
    //     if (loading || projectData?.total === undefined) return

    // }, [])

    // const rowMemo = useCallback((item) => {
    //     return (
    //         <div>
    //             {item.des}
    //         </div>
    //     )
    // }, [])

debugger

    return <div className="tab_body">
        {/* <ScorllListView 
            ref={bsRef} 
            height={400} 
            refreshing={loading}
            reload={reload} 
            loadMore={loadMore} 
            loadingMore={loadingMore}
             noMore={noMore} 
             data={data?.list} 
             row={rowMemo} /> */}
             1
    </div>
}

export default Pullrefresh;


