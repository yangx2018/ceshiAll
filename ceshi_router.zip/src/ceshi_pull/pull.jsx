//下拉刷新&上拉加载更多
import React, { forwardRef, useState, useEffect } from "react";
import "./style.less";
import { PullToRefresh, ListView } from "antd-mobile";
// export interface Iprops {
//   height: any;
//   refreshing: boolean;
//   loadingMore?: boolean;
//   noMore?: boolean;
//   reload: () => void;
//   ref: any;
//   data: any[];
//   loadMore?: () => void;
//   row: (e: any, i?: number) => any;
//   renderFiler?: () => void;
//   renderSearcher?: () => void;
// }
const ScorllToRefresh = forwardRef(
  ({ height, refreshing, row, reload, loadMore, loadingMore, data = [], noMore = false, renderFiler, renderSearcher, }, ref) => {
    const [dataSource, setDateSource] = useState(new ListView.DataSource({ rowHasChanged: (row1, row2) => row1 !== row2 }));

    useEffect(() => {
      console.log("datadata", data)
      if (!data || refreshing || loadingMore) return;
      setDateSource(dataSource.cloneWithRows(data));
    }, [data, refreshing, loadingMore]);

    return (
      <ListView
        ref={(el) => ref}
        dataSource={dataSource}
        // renderHeader={() => (
        //   <>
        //     {renderSearcher && renderSearcher()}
        //     {renderFiler && renderFiler()}
        //   </>
        // )}
        renderFooter={() => (
          <div className="foot_box">
            {(!refreshing && data?.length === 0) && <div className="entry_box" >暂无数据</div>}
            <div className="footer">{noMore ? "没有更多" : loadingMore ? "加载中" : "正在加载"}</div>
          </div>
        )}
        renderRow={(rowData, sectionID, rowID) => {
          return row(rowData, rowID);
        }}
        renderSeparator={(sectionID, rowID) => {
          return <div key={rowID} className="row_separator" />;
        }}
        useBodyScroll={false}
        style={{ height: height - 1, border: "1px solid #ddd", margin: "5px 0" }}
        pullToRefresh={
          <PullToRefresh
            damping={window.devicePixelRatio * 25}
            distanceToRefresh={window.devicePixelRatio * 25}
            getScrollContainer={() => undefined}
            indicator={{ deactivate: "下拉可以刷新" }}
            refreshing={refreshing}
            direction={"down"}
            onRefresh={() => {
              if (refreshing) return
              reload()
            }}
          />
        }
        scrollEventThrottle={10}
        // onEndReachedThreshold={10}
        onEndReached={() => {
          if (loadingMore) return
          loadMore && loadMore()
        }}
      // pageSize={}
      />
    );
  }
);
export default ScorllToRefresh;
