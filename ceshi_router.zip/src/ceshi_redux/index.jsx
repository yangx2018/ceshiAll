import React , { useState } from "react";
import ReactReduxCounter from "./ReactReduxCounter";

const CeshiRedux = () => {
  const [asaa,setasaa] = useState(1)

  return (
    <div>
      <p>asaa{asaa}</p>
      <ReactReduxCounter />
    </div>
  );
}

export default CeshiRedux;

