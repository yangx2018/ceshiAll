
import React,{Suspense} from 'react';
import { Route, Switch, BrowserRouter  } from "react-router-dom";
import Ceshi1 from './select'

const Timer_Ceshi = ({match,...res}) => {
  

  return (
    <BrowserRouter>
      <Suspense fallback={<div>LoadingLoadingLoadingLoadingLoadingLoadingLoadingLoading</div>}>
        <Switch>
          <Route path={`${match.path}/ceshi1`} component={Ceshi1} />
          <Route path="/"  render={() => <div>各种组件实验</div>} />
        </Switch>
      </Suspense>
    </BrowserRouter>
  );
}

export default Timer_Ceshi;
