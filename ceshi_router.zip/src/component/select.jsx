import React,{useEffect,useState} from 'react'
// import {Picker,List,InputItem} from 'antd-mobile'

const Select_C = () => {
    console.log('antd')
    const sss = [{ label: '2013', value: '2013'},{label: '2014',value: '2014'}]

    // const ttt = () => {
    //     return (
    //         <InputItem
    //             value="adasdasdas"
    //             editable={false}
    //         ></InputItem>
    //     )
    // }

    return (
        
        <div style={{width:500}}>
                {/* <Picker data={sss} cols={1} value={[]} extra={ttt()}>
                    <List.Item arrow="horizontal">Single</List.Item>
                </Picker> */}
                <div>a</div>
        </div>   
    )
}

export default Select_C