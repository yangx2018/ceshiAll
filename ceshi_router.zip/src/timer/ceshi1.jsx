
import React, { useState, useEffect } from "react";
const Timer_ceshi1 = () => {
    // 倒计时
  let [countDown, setCountDown] = useState(0);

  // 定时器
  let [timer, setTimer] = useState(0);

  // 改变倒计时 countDown 的值
  const handleTimer = () => {
    setCountDown(10);
  };

  // 使用 useEffect 监听 countDown 变化
  useEffect(() => {
    if (countDown > 0) {
      const newTimer = window.setInterval(() => {
        if (countDown < 1) {
          console.log("倒计时结束:", countDown);
          window.clearInterval(newTimer);
        } else {
          setCountDown((countDown -= 1));
        }
      }, 1000);

      setTimer(newTimer);
    }
  }, [countDown]);
  console.log("??",timer)

  // 组件销毁清除倒计时
  useEffect(() => {
    return () => window.clearInterval(timer);
  }, [timer]);

  return (
    <div>
      <h1>修改后的案例</h1>
      <button type="button" onClick={() => handleTimer()}>
        定时器
      </button>
      <h1>{countDown}</h1>
    </div>
  );

}

export default Timer_ceshi1;

