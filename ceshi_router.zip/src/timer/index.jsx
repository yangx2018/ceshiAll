
import React,{Suspense} from 'react';
import { Route, Switch, BrowserRouter  } from "react-router-dom";

const OtherCeshi2 = React.lazy(() => import('./ceshi1'));
const Timer_Ceshi = ({match,...res}) => {
  

  return (
    <BrowserRouter>
      <Suspense fallback={<div>LoadingLoadingLoadingLoadingLoadingLoadingLoadingLoading</div>}>
        <Switch>
          <Route path="/"  component={OtherCeshi2} />
          <Route path={`${match.path}/kk`} render={() => <div>ceshishsihsihsihsihsihsihsihsishi</div>} />
        </Switch>
      </Suspense>
    </BrowserRouter>
  );
}

export default Timer_Ceshi;
